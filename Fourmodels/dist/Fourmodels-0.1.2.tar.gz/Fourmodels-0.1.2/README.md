This Package is used for comparing Four Models

model_types = ['CNN', 'CNN+LSTM', 'CNN+RNN', 'XGBOOST']